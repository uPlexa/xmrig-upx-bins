Make sure to edit config.json
Replace:
            "user": "UPX1VTg9uaaTvHMR4fstZMVBQ3K95H3P49vKv3iGkgCDQXxWgj5M2VPQcgMHioKg2WPr1iDnUcKSNdtPv3AXer6322XwfodpaW",
With your UPX address.

You may obtain a UPX address from https://airdrop.uplexa.com

If you are using highend devices, change upx.poolbux.com:3333 to upx.poolbux.com:5555

Patches:
v0.0.2 - Fixed algorithm name & Crashing


If you're on Linux and running into depdency issues, install the following:
(Ubuntu)::
sudo apt-get install git build-essential cmake libuv1-dev libmicrohttpd-dev libssl-dev
